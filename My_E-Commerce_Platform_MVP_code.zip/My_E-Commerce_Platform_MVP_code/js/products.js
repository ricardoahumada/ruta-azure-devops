const products = [
  { id: 1, name: 'Camiseta Básica', price: 19.99, category: 'Ropa' },
  { id: 2, name: 'Zapatos Deportivos', price: 59.99, category: 'Calzado' },
  { id: 3, name: 'Libro de JavaScript', price: 12.99, category: 'Libros' },
  { id: 4, name: 'Audífonos Bluetooth', price: 39.99, category: 'Electrónica' }
];
